
<?php
include 'header.php';
?>
<section style="padding: 18% 0 15% 0;" >
  <div class="notification notice closeable container" >
				<p>Your Request has been Submitted!</p>
				<a class="close"></a>
			</div>
      </section>
<?php
include 'footer.php';
?>